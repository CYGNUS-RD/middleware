"""
To run these tests, you can use unittest's test discovery:

```
cd $MIDASSYS/python/tests
python -munittest
```
"""